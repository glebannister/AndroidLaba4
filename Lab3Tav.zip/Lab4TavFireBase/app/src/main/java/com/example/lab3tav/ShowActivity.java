package com.example.lab3tav;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ShowActivity extends AppCompatActivity {
    private TextView tvName, tvPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        init();
        getIntentMain();
    }

    private void init() {
        tvName = findViewById(R.id.tvName);
        tvPoints = findViewById(R.id.tvPoints);

    }
    private void getIntentMain(){
        Intent i = getIntent();
        if (i != null){
            tvName.setText(i.getStringExtra(Constant.USER_NAME));
            tvPoints.setText(i.getStringExtra(Constant.POINTS));
        }
    }

    public void onClickBack(View view){
        Intent in = new Intent(getApplicationContext(),TopActivity.class);
        startActivity(in);
    }
}