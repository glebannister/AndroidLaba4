package com.example.lab3tav;

public class Constant {
    public final static String USER_NAME = "user_name";
    public final static String POINTS = "points";
}
