package com.example.lab3tav;

public class Top {
    public String id, userName, points;

    public Top() {
    }

    public Top(String id, String userName, String points) {
        this.id = id;
        this.userName = userName;
        this.points = points;
    }
}
